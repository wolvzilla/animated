package com.example.animated;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.razerdp.widget.animatedpieview.AnimatedPieView;
import com.razerdp.widget.animatedpieview.AnimatedPieViewConfig;
import com.razerdp.widget.animatedpieview.callback.OnPieSelectListener;
import com.razerdp.widget.animatedpieview.data.IPieInfo;
import com.razerdp.widget.animatedpieview.data.SimplePieInfo;

public class MainActivity extends AppCompatActivity {
AnimatedPieView animatedPieView;
TextView tveasy,tvdifficult,tvengaging,tvboring;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tveasy= findViewById(R.id.tveasy);
        tvdifficult=findViewById(R.id.tvdifficult);
        tvengaging=findViewById(R.id.tvengaging);
        tvboring=findViewById(R.id.tvboring);

        animatedPieView=findViewById(R.id.animatedpieView);
        AnimatedPieViewConfig config=new AnimatedPieViewConfig();
        config.addData(new SimplePieInfo(60,Color.parseColor("#AAFF0000"),"30%"));
        config.addData(new SimplePieInfo(10,Color.parseColor("#AA00FF00"),"10" ));
        config.addData(new SimplePieInfo(20,Color.parseColor("#AA0000FF"),"20" ));
        config.addData(new SimplePieInfo(10,Color.parseColor("#AA000000"),"10" ));
        config.duration(1000);

        config.drawText(true);
        config.strokeMode(false);
        config.textSize(52);
        config.selectListener(new OnPieSelectListener<IPieInfo>() {
            @Override
            public void onSelectPie(@NonNull IPieInfo pieInfo, boolean isFloatUp) {
                Toast.makeText(MainActivity.this,pieInfo.getDesc()+"-"+pieInfo.getValue(),Toast.LENGTH_SHORT).show();
            }
        });

        config.startAngle(-50);

        animatedPieView.applyConfig(config);
        animatedPieView.start();

    }
}
